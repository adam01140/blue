/**
 * Local dev server for Flowchart Creation Tool + FormWiz preview.
 * Serves the whole repo on port 8080 and implements POST /edit_pdf so
 * Preview/Download PDF works (http-server alone returns 405 for POST).
 */
require('dotenv').config();
const express = require('express');
const bodyParser = require('body-parser');
const fileUpload = require('express-fileupload');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const JSZip = require('jszip');
const { PDFDocument, StandardFonts } = require('pdf-lib');
const { preparePayloadHtml, sanitizePayloadFolderName } = require('./payload-html');

const ROOT = __dirname;
const FORM_WIZ_DIR = path.join(ROOT, 'FormWiz GUI');
const PUBLIC_DIR = path.join(ROOT, 'public');
const PORT = process.env.PORT || 8080;
const OPENAI_API_KEY = process.env.OPENAI_API_KEY;

const app = express();
// Auto-Form-Creator AI generation routes accept large JSON payloads (configs, extraction text).
const AUTO_FORM_BODY_LIMIT = '50mb';
[
  '/api/auto-form',
  '/api/demo-hub',
  '/api/generate-field-config',
  '/api/generate-form-config',
  '/api/generate-form-html'
].forEach((prefix) => {
  app.use(prefix, bodyParser.json({ limit: AUTO_FORM_BODY_LIMIT }));
  app.use(prefix, bodyParser.urlencoded({ extended: true, limit: AUTO_FORM_BODY_LIMIT }));
});
app.use(bodyParser.json({ limit: '2mb' }));
app.use(bodyParser.urlencoded({ extended: true, limit: '2mb' }));
app.use(fileUpload({
  limits: { fileSize: 80 * 1024 * 1024 },
  defCharset: 'utf8',
  defParamCharset: 'utf8'
}));
app.use(cors());

app.use((req, res, next) => {
  if (req.path === '/.env' || req.path.endsWith('.env')) {
    return res.status(404).end();
  }
  next();
});

function shouldCheck(v) {
  if (v === undefined || v === null || v === '') return false;
  if (Array.isArray(v)) return v.length > 0;
  const s = String(v).trim().toLowerCase();
  return s === 'on' || s === 'true' || s === 'yes' || s === '1' || s === 'checked';
}

function mapRadioValue(field, value) {
  try {
    const options = field.getOptions();
    const valueStr = String(value).trim();
    if (options.includes(valueStr)) return valueStr;
    if (valueStr === 'on' || valueStr === 'true' || valueStr === '1') {
      const yesOption = options.find((opt) =>
        opt.toLowerCase().includes('yes') ||
        opt.toLowerCase().includes('true') ||
        opt.toLowerCase().includes('1')
      );
      if (yesOption) return yesOption;
      if (options.length > 0) return options[0];
    }
    if (valueStr === 'off' || valueStr === 'false' || valueStr === '0') {
      const noOption = options.find((opt) =>
        opt.toLowerCase().includes('no') ||
        opt.toLowerCase().includes('false') ||
        opt.toLowerCase().includes('0')
      );
      if (noOption) return noOption;
    }
    if (valueStr.includes(',')) {
      const parts = valueStr.split(',').map((p) => p.trim()).filter(Boolean);
      if (parts.length > 0) return mapRadioValue(field, parts[0]);
    }
    const partialMatch = options.find((opt) =>
      opt.toLowerCase().includes(valueStr.toLowerCase()) ||
      valueStr.toLowerCase().includes(opt.toLowerCase())
    );
    return partialMatch || null;
  } catch (error) {
    return null;
  }
}

function findPdfFile(targetFile) {
  const targetLower = path.basename(targetFile).toLowerCase();
  const searchRoots = [
    FORM_WIZ_DIR,
    path.join(FORM_WIZ_DIR, 'public', 'Forms'),
    ROOT
  ];

  for (const rootDir of searchRoots) {
    if (!fs.existsSync(rootDir)) continue;

    const direct = path.join(rootDir, targetLower);
    if (fs.existsSync(direct) && fs.lstatSync(direct).isFile()) {
      return direct;
    }

    const stack = [rootDir];
    while (stack.length) {
      const current = stack.pop();
      let entries;
      try {
        entries = fs.readdirSync(current, { withFileTypes: true });
      } catch (e) {
        continue;
      }
      for (const entry of entries) {
        const fullPath = path.join(current, entry.name);
        if (entry.isDirectory()) {
          stack.push(fullPath);
        } else if (entry.isFile() && entry.name.toLowerCase() === targetLower) {
          return fullPath;
        }
      }
    }
  }

  return null;
}

app.post('/edit_pdf', async (req, res) => {
  try {
    let pdfBytes;
    let outputName = 'Edited_document.pdf';

    if (req.files && req.files.pdf) {
      pdfBytes = req.files.pdf.data;
      outputName = `Edited_${req.files.pdf.name}`;
    } else {
      const pdfName = req.query.pdf;
      if (!pdfName) {
        return res.status(400).send('No PDF provided (upload a file or pass ?pdf=filename).');
      }
      const normalizedBase = path.basename(pdfName).replace(/\.pdf$/i, '');
      const sanitized = normalizedBase + '.pdf';
      const pdfPath = findPdfFile(sanitized);
      if (!pdfPath) {
        return res.status(400).send(`Requested PDF does not exist on the server: ${sanitized}`);
      }
      pdfBytes = await fs.promises.readFile(pdfPath);
      outputName = `Edited_${path.basename(pdfPath)}`;
      console.log(`Using PDF: ${path.relative(ROOT, pdfPath)}`);
    }

    const pdfDoc = await PDFDocument.load(pdfBytes);
    const form = pdfDoc.getForm();
    const helv = await pdfDoc.embedFont(StandardFonts.Helvetica);

    form.getFields().forEach((field) => {
      const key = field.getName();
      const value = req.body[key];
      if (value === undefined) return;

      try {
        switch (field.constructor.name) {
          case 'PDFCheckBox':
            shouldCheck(value) ? field.check() : field.uncheck();
            break;
          case 'PDFRadioGroup': {
            const radioValue = mapRadioValue(field, value);
            if (radioValue) field.select(radioValue);
            break;
          }
          case 'PDFDropdown':
            field.select(String(value));
            break;
          case 'PDFTextField':
            field.setText(String(value));
            field.updateAppearances(helv);
            break;
          default:
            if (typeof field.setText === 'function') {
              field.setText(String(value));
              if (typeof field.updateAppearances === 'function') {
                field.updateAppearances(helv);
              }
            }
            break;
        }
      } catch (error) {
        console.warn(`Field ${key}:`, error.message);
      }
    });

    const edited = await pdfDoc.save();
    res
      .set({
        'Content-Type': 'application/pdf',
        'Content-Disposition': `inline; filename="${outputName}"`
      })
      .send(Buffer.from(edited));
  } catch (error) {
    console.error('edit_pdf failed:', error);
    res.status(500).send('Failed to fill PDF: ' + error.message);
  }
});

app.post('/api/test-payload', express.json({ limit: '50mb' }), async (req, res) => {
  try {
    const folderName = sanitizePayloadFolderName(req.body && req.body.folderName);
    let html = preparePayloadHtml((req.body && req.body.html) || '');
    if (!html.trim()) {
      return res.status(400).send('Missing html for test payload.');
    }
    if (!/^<!DOCTYPE/i.test(html)) {
      html = '<!DOCTYPE html>\n' + html;
    }

    const zip = new JSZip();
    const folder = zip.folder(folderName);
    folder.file('index.html', html);

    const staticAssets = ['generate.css', 'generate2.css', 'logo.png'];
    staticAssets.forEach((asset) => {
      const assetPath = path.join(FORM_WIZ_DIR, asset);
      if (fs.existsSync(assetPath) && fs.lstatSync(assetPath).isFile()) {
        folder.file(asset, fs.readFileSync(assetPath));
      }
    });

    const pdfNames = Array.isArray(req.body.pdfs) && req.body.pdfs.length
      ? req.body.pdfs
      : ['W9.pdf'];
    pdfNames.forEach((pdfName) => {
      const normalized = path.basename(String(pdfName).trim());
      if (!normalized) return;
      const withExt = /\.pdf$/i.test(normalized) ? normalized : normalized + '.pdf';
      const pdfPath = findPdfFile(withExt);
      if (pdfPath) {
        folder.file(withExt, fs.readFileSync(pdfPath));
      }
    });

    folder.file(
      'README.txt',
      [
        'Test payload for FormWiz',
        '',
        '1. Unzip this folder into:',
        '   FlowchartCreationTool/FormWiz GUI/',
        '',
        '2. Start the dev server from the project root:',
        '   npm start',
        '',
        '3. Open in your browser:',
        `   http://127.0.0.1:8080/FormWiz%20GUI/${encodeURIComponent(folderName)}/index.html`,
        '',
        'PDF preview and download use POST /edit_pdf on the same dev server.',
        'Run npm start (dev-server.js), not plain http-server.'
      ].join('\n')
    );

    const buf = await zip.generateAsync({ type: 'nodebuffer', compression: 'DEFLATE' });
    res
      .set({
        'Content-Type': 'application/zip',
        'Content-Disposition': `attachment; filename="${folderName}.zip"`
      })
      .send(buf);
  } catch (error) {
    console.error('test-payload failed:', error);
    res.status(500).send('Failed to build test payload: ' + error.message);
  }
});

// ────────────────────────────────────────────────────────────
// Auto-Form-Creator (ported from the Finance Forms "blue" server.js)
// Page: http://127.0.0.1:8080/Auto-Form-Creator/demo.html
// Handlers live in ./auto-form-server/ and read/write ./public/Auto-Form-Creator/.
// AI steps need OPENAI_API_KEY in .env; publish/admin steps need the FIREBASE_* vars.
// ────────────────────────────────────────────────────────────
let db = null;
if (process.env.FIREBASE_PROJECT_ID && process.env.FIREBASE_PRIVATE_KEY) {
  try {
    const admin = require('firebase-admin');
    admin.initializeApp({
      credential: admin.credential.cert({
        type: 'service_account',
        project_id: process.env.FIREBASE_PROJECT_ID,
        private_key_id: process.env.FIREBASE_PRIVATE_KEY_ID,
        private_key: process.env.FIREBASE_PRIVATE_KEY.replace(/\\n/g, '\n'),
        client_email: process.env.FIREBASE_CLIENT_EMAIL,
        client_id: process.env.FIREBASE_CLIENT_ID,
        auth_uri: 'https://accounts.google.com/o/oauth2/auth',
        token_uri: 'https://oauth2.googleapis.com/token',
        auth_provider_x509_cert_url: 'https://www.googleapis.com/oauth2/v1/certs',
        client_x509_cert_url: `https://www.googleapis.com/robot/v1/metadata/x509/${process.env.FIREBASE_CLIENT_EMAIL}`
      }),
      databaseURL: `https://${process.env.FIREBASE_PROJECT_ID}.firebaseio.com`,
      storageBucket: `${process.env.FIREBASE_PROJECT_ID}.firebasestorage.app`
    });
    db = admin.firestore();
    console.log('Firebase Admin initialized (Auto-Form publish/admin enabled).');
  } catch (error) {
    console.warn('Firebase Admin not initialized; publish/admin routes disabled:', error.message);
  }
} else {
  console.warn('FIREBASE_* env vars missing; Auto-Form publish/admin routes disabled.');
}
if (!OPENAI_API_KEY) {
  console.warn('OPENAI_API_KEY missing; Auto-Form AI generation steps will fail until it is set in .env.');
}

const { handleUnlockPdf, handlePreparePdfFields } = require('./auto-form-server/unlock-pdf-handler');
const { createHandleGenerateFieldConfig } = require('./auto-form-server/field-config-generator');
const { handleSanitizePdf } = require('./auto-form-server/pdf-field-sanitizer');
const { createHandleGenerateFormConfig } = require('./auto-form-server/form-config-generator');
const { createHandleGenerateFormHtml } = require('./auto-form-server/form-html-generator');
const { enrichFormConfigAutopopulate } = require('./auto-form-server/form-autopopulate');
const {
  handleStoreAutoFormPdf,
  handleFillAutoFormPdf,
  handleDemoHubFillPdf,
  rehydratePdfStore
} = require('./auto-form-server/auto-form-pdf-handler');
const {
  handleCreateEntry,
  handleUpdateEntry,
  handleDeleteEntry,
  handleListEntries,
  handleGetEntryHtml,
  handleGetEntryPdf
} = require('./auto-form-server/demo-hub-admin');
const { createHandlePublishAutoForm } = require('./auto-form-server/auto-form-publish-handler');
const { createHandleSaveCurrentData } = require('./auto-form-server/auto-form-current-data');
const { createHandleHelpAnswer } = require('./auto-form-server/auto-form-help-handler');

app.post('/api/unlock-pdf', handleUnlockPdf);
app.post('/api/prepare-pdf-fields', handlePreparePdfFields);
app.post('/api/generate-field-config', createHandleGenerateFieldConfig(OPENAI_API_KEY));
app.post('/api/sanitize-pdf', handleSanitizePdf);
app.post('/api/generate-form-config', createHandleGenerateFormConfig(OPENAI_API_KEY));
app.post('/api/generate-form-html', createHandleGenerateFormHtml(OPENAI_API_KEY));
app.post('/api/enrich-autopopulate', (req, res) => {
  try {
    const { formConfig, fieldConfig, userProfile, displayMode } = req.body || {};
    if (!formConfig) {
      return res.status(400).json({ success: false, error: 'formConfig is required' });
    }
    const enriched = enrichFormConfigAutopopulate(
      formConfig,
      userProfile || {},
      displayMode || 'all_at_once',
      fieldConfig || null
    );
    res.json({ success: true, formConfig: enriched });
  } catch (error) {
    console.error('[enrich-autopopulate] Error:', error);
    res.status(500).json({ success: false, error: error.message || 'Failed to enrich autopopulate' });
  }
});
app.post('/api/auto-form/store-pdf', handleStoreAutoFormPdf);
app.post('/api/auto-form/fill-pdf/:pdfToken', handleFillAutoFormPdf);
app.post('/api/demo-hub/fill-pdf/:slug', handleDemoHubFillPdf);
app.get('/api/demo-hub/entries', handleListEntries);
app.post('/api/demo-hub/entries', handleCreateEntry);
app.put('/api/demo-hub/entries/:slug', handleUpdateEntry);
app.delete('/api/demo-hub/entries/:slug', handleDeleteEntry);
app.get('/api/demo-hub/files/:slug/html', handleGetEntryHtml);
app.get('/api/demo-hub/files/:slug/pdf/:index', handleGetEntryPdf);
app.post('/api/auto-form/publish', createHandlePublishAutoForm(db));
app.post('/api/auto-form/save-current-data', createHandleSaveCurrentData());
app.post('/api/auto-form/help-answer', createHandleHelpAnswer(OPENAI_API_KEY));

function requireDb(res) {
  if (db) return true;
  res.status(503).json({ success: false, error: 'Firebase Admin is not configured (set FIREBASE_* in .env).' });
  return false;
}
app.post('/api/admin-save-form', async (req, res) => {
  if (!requireDb(res)) return;
  try {
    const { formId, formData } = req.body || {};
    if (!formId || !formData) {
      return res.status(400).json({ success: false, error: 'Form ID and form data are required' });
    }
    const { id, ...dataToSave } = formData;
    await db.collection('forms').doc(formId).set(dataToSave);
    res.json({ success: true, message: 'Form saved successfully' });
  } catch (error) {
    console.error('Error saving admin form:', error);
    res.status(500).json({ success: false, error: 'Failed to save form' });
  }
});
app.delete('/api/admin-delete-form/:formId', async (req, res) => {
  if (!requireDb(res)) return;
  try {
    await db.collection('forms').doc(req.params.formId).delete();
    res.json({ success: true, message: 'Form deleted successfully' });
  } catch (error) {
    console.error('Error deleting admin form:', error);
    res.status(500).json({ success: false, error: 'Failed to delete form' });
  }
});

// Static: public/ (Auto-Form-Creator, Forms/CSS, CountyLookup, Pages) is served at the web root,
// same as the blue server, so /Auto-Form-Creator/demo.html and /Forms/CSS/*.css resolve.
app.use(express.static(PUBLIC_DIR));
app.use('/vendor/pdfjs', express.static(path.join(ROOT, 'node_modules', 'pdfjs-dist', 'build')));
app.use('/vendor/pdfjs-legacy', express.static(path.join(ROOT, 'node_modules', 'pdfjs-dist', 'legacy', 'build')));
app.use(express.static(ROOT));

app.get('/', (_req, res) => {
  res.redirect('/index.html');
});

rehydratePdfStore();
app.listen(PORT, () => {
  console.log(`Flowchart dev server running at http://127.0.0.1:${PORT}`);
  console.log(`Auto-Form-Creator demo: http://127.0.0.1:${PORT}/Auto-Form-Creator/demo.html`);
  console.log('PDF fill endpoint: POST /edit_pdf?pdf=W9.pdf');
  console.log(`Looking for PDFs in: ${FORM_WIZ_DIR}`);
}).on('error', (err) => {
  if (err.code === 'EADDRINUSE') {
    console.error(`Port ${PORT} is already in use (likely an old http-server).`);
    console.error('Stop it, then run npm start again. Or set PORT=8088 npm start');
    process.exit(1);
  }
  throw err;
});
